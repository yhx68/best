#' 1000 cases.
#'
#' A dataset containing the TCT.status and other factors for 1000 patients
#'
#' @docType data
#'
#' @usage cervical
#'
#' @format A data frame with 1000 rows and 16 variables:
#' \describe{
#'   \item{TCT.status}{}
#'   \item{HPV}{}
#'   \item{Age}{}
#'   \item{Age.at.first.sexual.intercourse}{}
#'   \item{Number.of.sexual.partners}{}
#'   \item{Number.of.previous.pregnancies}{}
#'   \item{Menstruation.status}{}
#'   \item{Main.contraceptive.measures}{}
#'   \item{Marital.status}{}
#'   \item{Education.levels}{}
#'   \item{Annual.household.income}{}
#'   \item{History.of.HPV.infection}{}
#'   \item{Knowledge.about.HPV.infection.route}{}
#'   \item{Hygiene.practices.during.sexual.activity}{}
#'   \item{Participation.in.routine.cervical.screening}{}
#'   \item{HPV.vaccination.status}{}
#' }
'cervical'
