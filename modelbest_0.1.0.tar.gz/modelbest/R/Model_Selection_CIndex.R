Model_Selection_CIndex=function(data){

cervical=data
for(i in 2:ncol(cervical)){
  cervical[,i]=factor(cervical[,i])
}

num_factors=ncol(cervical)-1
names_y=colnames(cervical)[1]
names_factors=colnames(cervical)[2:ncol(cervical)]
formula=paste(names_y,paste(names_factors,collapse = '+'),sep='~')

mylog<- glm(formula,family=binomial(link = "logit"),data = cervical)
p_values=summary(mylog)$coefficients[,4]
variable_names=rownames(summary(mylog)$coefficients)
pos=NULL
for(i in 1:num_factors){
  str=names_factors[i]
  pos_temp=which(grepl(str,variable_names))
  if(any(p_values[pos_temp]<0.05)){
    pos=c(pos,i)
  }
}

names_factors_significant=names_factors[pos]
formula=paste(names_y,paste(names_factors_significant,collapse = '+'),sep='~')

simplog<- glm(formula,family=binomial(link = "logit"),data=cervical)

reclassification_new=function (data, cOutcome, predrisk1, predrisk2, cutoff)
{
  c1 <- cut(predrisk1, breaks = cutoff, include.lowest = TRUE,
            right = FALSE)
  c2 <- cut(predrisk2, breaks = cutoff, include.lowest = TRUE,
            right = FALSE)
  c11 <- factor(c1, levels = levels(c1), labels = c(1:length(levels(c1))))
  c22 <- factor(c2, levels = levels(c2), labels = c(1:length(levels(c2))))
  x <- improveProb(x1 = as.numeric(c11) * (1/(length(levels(c11)))),
                   x2 = as.numeric(c22) * (1/(length(levels(c22)))), y = data[,
                                                                              cOutcome])
  y <- improveProb(x1 = predrisk1, x2 = predrisk2, y = data[,
                                                            cOutcome])

  NRI_Categorical=c(round(x$nri, 4),round(x$nri - 1.96 * x$se.nri, 4),round(x$nri + 1.96 * x$se.nri, 4),round(2 * pnorm(-abs(x$z.nri)), 5))
  names(NRI_Categorical)=c('NRI_Categorical','%95_CI_lower','%95_CI_higher','p-value')

  NRI_Continuous=c(round(y$nri, 4),round(y$nri -1.96 * y$se.nri, 4),round(y$nri + 1.96 * y$se.nri,4),round(2 * pnorm(-abs(y$z.nri)),5))
  names(NRI_Continuous)=c('NRI_Continuous','%95_CI_lower','%95_CI_higher','p-value')

  IDI=c(round(y$idi, 4),round(y$idi -1.96 * y$se.idi, 4),round(y$idi + 1.96 * y$se.idi,4),round(2 * pnorm(-abs(y$z.idi)),5))
  names(IDI)=c('IDI','%95_CI_lower','%95_CI_higher','p-value')

  result=list(NRI_Categorical,NRI_Continuous,IDI)

  return(result)
}

rs=NULL
pstd <- simplog$fitted.values
for(i in 1:num_factors){
  print(i)
  comb_factors=t(combn(num_factors,i))
  comb_num=nrow(comb_factors)
  for(j in 1:comb_num){
    pos=comb_factors[j,]
    factors_used=names_factors[pos]
    formula=paste(names_y,paste(factors_used,collapse = '+'),sep='~')
    model=glm(formula,family=binomial(link = "logit"),data=cervical,x=TRUE)
    C <- rcorrcens(cervical[,1]~predict(model))
    C_index=C[1] #C-index
    se=C[4]/sqrt(C[7]) #standard error
    CI=c(C_index-1.96*se,C_index+1.96*se) #confidence interval of C-index

    pnew <- model$fitted.values
    result=reclassification_new(data = cervical,cOutcome = 1,
                     predrisk1 = pstd,predrisk2 = pnew,
                     cutoff = c(0,0.30,0.60,1))   #NRI and IDI

    rs=rbind(rs,c(formula,i,C_index,CI,result[[1]],result[[2]],result[[3]]))
  }
}

rs=as.data.frame(rs)
colnames(rs)=c('model_formula','number_of_variables','C_index','%95_CI_lower','%95_CI_higher','NRI_Categorical','%95_CI_lower','%95_CI_higher','p-value','NRI_Continuous','%95_CI_lower','%95_CI_higher','p-value','IDI','%95_CI_lower','%95_CI_higher','p-value')
pos=order(rs$C_index,decreasing=T)  #order with C-index
out=rs[pos,]
write.table(out,'modelbest_results.txt',sep="\t",row.names=F)

return(out)

}





